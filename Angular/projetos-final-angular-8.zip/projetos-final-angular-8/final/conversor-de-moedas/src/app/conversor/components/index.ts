export * from './conversor.component';
